package com.example.reservationsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import jakarta.persistence.*;
import java.util.List;

@SpringBootApplication
public class ReservationSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReservationSystemApplication.class, args);
    }
}

// ======================= ENTITY =======================
@Entity
class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String date;
    private String time;
    private int seats;

    public Reservation() {}
    public Reservation(String name, String email, String date, String time, int seats) {
        this.name = name; this.email = email; this.date = date; this.time = time; this.seats = seats;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    public int getSeats() { return seats; }
    public void setSeats(int seats) { this.seats = seats; }
}

// ======================= REPOSITORY =======================
interface ReservationRepository extends JpaRepository<Reservation, Long> {}

// ======================= SERVICE =======================
@Service
class ReservationService {
    private final ReservationRepository repo;
    public ReservationService(ReservationRepository repo) { this.repo = repo; }

    public Reservation addReservation(Reservation reservation) { return repo.save(reservation); }
    public List<Reservation> getAllReservations() { return repo.findAll(); }
    public void deleteReservation(Long id) { repo.deleteById(id); }
}

// ======================= CONTROLLER =======================
@RestController
@RequestMapping("/api/reservations")
class ReservationController {
    private final ReservationService service;
    public ReservationController(ReservationService service) { this.service = service; }

    @PostMapping
    public Reservation createReservation(@RequestBody Reservation reservation) {
        return service.addReservation(reservation);
    }

    @GetMapping
    public List<Reservation> getAllReservations() {
        return service.getAllReservations();
    }

    @DeleteMapping("/{id}")
    public String deleteReservation(@PathVariable Long id) {
        service.deleteReservation(id);
        return "Reservation with ID " + id + " deleted.";
    }
}
